package com.bit.day20;

import java.util.ArrayList;

public class Ex09 {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("item1");
		list.add("item1");
		list.add("item1");
//		list.add(1234);
		
		String item1 = list.get(0);
		String item2 = list.get(1);
		String item3 = list.get(2);
		
		
		
	}
}
