package com.bit.day20;

import java.util.ArrayList;
import java.util.LinkedList;

public class Ex12 {
	public static void main(String[] args) {
		LinkedList<Double> link = new LinkedList<>();
		link.add(3.14);
		link.add(1.0);
		ArrayList<Number> list = new ArrayList<Number>(link);
		Number[] arr = null;
		Number[] result =  list.toArray(arr);
		System.out.print(result);
	}
}
